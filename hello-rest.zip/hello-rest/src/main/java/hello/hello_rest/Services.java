package hello.hello_rest;

public class Services {

	String original, reverse = "";
	 static final int NO_OF_CHARS = 256;
      private Greeting greeting=null; 
	
      private boolean flag=false; 
      
	public Greeting Ispalindrom(String words){
	
	      original =words;
	      int length = original.length();
	      for (int i = length - 1; i >= 0; i--)
	         reverse = reverse + original.charAt(i);
	      if (original.equals(reverse))
	      {
	       System.out.println("The string is a palindrome.");
	      greeting=new Greeting();
	      greeting.setPalindrome(true);
	      greeting.setAnagramOfPalindrome(false);
	      greeting.setWord(words);
	       flag=true; 
	       return greeting;
	     }
	      else if(true) {
	    	  System.out.println("The string is a not palindrome.");
	    	  greeting.setPalindrome(false);
	    	  greeting.setAnagramOfPalindrome(true);
	      }
		return greeting;
	   
	}
}


