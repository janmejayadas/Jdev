package hello.hello_rest;

import java.util.concurrent.atomic.AtomicLong;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WordController {
	private static final String MODULE = " [ GreetingController ], ";
	
   // private static final String template = "Hello, %s!";
    private final AtomicLong counter = new AtomicLong();
    private Greeting response=null;
    
    @RequestMapping(value="/greeting",method=RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
   
    public @ResponseBody Greeting greeting(@RequestParam(required = false, value = "words") String words) {
    	String method = "greeting";
    	
    	
		long startTime = System.currentTimeMillis();
		System.out.println(MODULE+ "IN " + method + " start with : RequestParam : " + words);
	
		
		
		Services s=new Services();
		response=s.Ispalindrom(words);
		long endTime = System.currentTimeMillis();
		System.out.println(MODULE+ method + "RESPONSE_IS: " + response);
		System.out.println(MODULE+ method + "TOTAL_TIMETAKEN" + (endTime - startTime) + " ms");
		
        return response;
        
    }
}