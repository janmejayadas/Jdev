package hello.hello_rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Scope;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WordController {
	private static final String MODULE = " [ WordController ], ";

	private ResponseVO responseVO=null;
	private Services services=null;
	
    @RequestMapping(value="/executeWords",method=RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
   
    public @ResponseBody ResponseVO executeWords(@RequestParam(required = false, value = "words") String words) {
    	String method = " [executeWords] ";
    	
		long startTime = System.currentTimeMillis();
		System.out.println(MODULE + " IN " + method + " start with : RequestParam : " + words);
		services=new Services();
		responseVO=new ResponseVO();
		
		responseVO.setWord(words);
		responseVO.setPalindrome(services.checkPalindrom(words));
		responseVO.setAnagramOfPalindrome(services.anagramOfPalindrome(words));
		
		long endTime = System.currentTimeMillis();
		System.out.println(MODULE + method + "RESPONSE_IS: " + responseVO);
		System.out.println(MODULE + method + "TOTAL_TIMETAKEN :" + (endTime - startTime) + " ms");
		return responseVO;
        
    }
}