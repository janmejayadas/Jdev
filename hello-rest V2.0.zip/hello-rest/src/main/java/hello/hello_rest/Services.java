package hello.hello_rest;


public class Services {

	private StringBuilder original = new StringBuilder(8);
	private StringBuilder reverse = new StringBuilder(8);

	public boolean checkPalindrom(String words) {
		if (null != words && words.trim().length() != 0) {
			int wordsLength = words.length();

			for (int i = wordsLength - 1; i >= 0; i--) {
				reverse.append(words.charAt(i));
			}
			System.out.println(reverse);
			if (words.equals(reverse.toString())) {
				return true;
			}
		}

		return false;
	}

	public boolean anagramOfPalindrome(String words) {

		if (null != words && 0 != words.trim().length()
				&& words.length() == reverse.length()) {
			int revWordsLength = reverse.length();

			for (int i = revWordsLength - 1; i >= 0; i--) {
				original.append(reverse.charAt(i));
			}
			if (words.equals(original.toString())) {
				return true;
			}
		}
		return false;
	}
}
